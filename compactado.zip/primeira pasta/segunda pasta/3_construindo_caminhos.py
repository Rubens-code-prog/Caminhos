from pathlib import Path


print(Path.home() / 'Documents' / 'assim_por_diante')